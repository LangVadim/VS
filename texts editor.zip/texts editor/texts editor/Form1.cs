﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;
using System.Diagnostics;

namespace texts_editor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)                             //Проверяем был ли выбран файл
            {
                richTextBox.Clear();                                                         //Очищаем richTextBox
                openFileDialog1.Filter = "Text Files (*.txt)|*.txt";                         //Указываем что нас интересуют только текстовые файлы
                string fileName = openFileDialog1.FileName;                                  //получаем наименование файл и путь к нему.
                richTextBox.Text = File.ReadAllText(fileName, Encoding.GetEncoding(1251));   //Передаем содержимое файла в richTextBox
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text Files|*.txt";                                    //Задаем доступные расширения
            saveFileDialog1.DefaultExt = ".txt";                                            //Задаем расширение по умолчанию 3
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)                            //Проверяем подтверждение сохранения информации.
            {
                var name = saveFileDialog1.FileName;                                        //Задаем имя файлу
                File.WriteAllText(name, richTextBox.Text, Encoding.GetEncoding(1251));      //Записываем в файл содержимое textBox с кодировкой 1251
            }
            richTextBox.Clear();
        }

        private void редактироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void сервисToolStripMenuItem_Click(object sender, EventArgs e)
        {
                                                                 //Отмена выделения

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font myFont = new Font("Tahoma", 12, FontStyle.Regular, GraphicsUnit.Pixel);
            string Hello = "Hello World!";
            e.Graphics.DrawString(Hello, myFont, Brushes.Black, 20, 20);

            pageSetupDialog1.ShowDialog();

            if (printDialog1.ShowDialog() == DialogResult.OK) printDocument1.Print();
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(richTextBox.SelectedText != "") 
            {
                richTextBox.Cut();
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextBox.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true) 
            {
                richTextBox.Paste();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            richTextBox.SelectAll();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectionLength > 0)
            {
                ColorDialog colorDialog = new ColorDialog();
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    richTextBox.SelectionColor = colorDialog.Color;
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            DialogResult result = fontDialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                richTextBox.SelectionFont = fontDialog.Font;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void выравниваниеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Select();                                                           // выравнивание только выделенного текста
            //richTextBox.SelectAll();                                                        //выделение всего текста
            richTextBox.SelectionAlignment = HorizontalAlignment.Center;
            richTextBox.DeselectAll();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                // здесь можно выполнить действия с выбранным файлом, например, прочитать его содержимое
            }
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Открытие диалогового окна сохранения файла
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            // Установка фильтра для сохраняемых файлов
            saveFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Получение имени файла, выбранного для сохранения
                string fileName = saveFileDialog.FileName;
                // Запись данных в файл
                using (StreamWriter writer = new StreamWriter(fileName))
                {
                    writer.Write(richTextBox.Text);
                }
                // Вывод сообщения об успешном сохранении файла
                MessageBox.Show("Файл сохранен успешно!");
            }
        }

        private void печататьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Имя файла, который необходимо распечатать
            string fileName = "example.txt";

            // Создаем объект класса PrintDocument
            PrintDocument pd = new PrintDocument();

            // Устанавливаем имя файла
            pd.DocumentName = fileName;

            // Создаем объект класса PrintDialog
            PrintDialog printDialog = new PrintDialog();

            // Устанавливаем диалоговое окно печати на основе PrintDocument
            printDialog.Document = pd;

            // Открываем диалоговое окно печати
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                // Устанавливаем начальную и конечную страницы документа
                pd.PrinterSettings.FromPage = 1;
                pd.PrinterSettings.ToPage = pd.PrinterSettings.MaximumPage;

                // Получаем массив байтов из файла
                byte[] fileBytes = System.IO.File.ReadAllBytes(fileName);

                // Создаем объект класса MemoryStream на основе массива байтов
                MemoryStream stream = new MemoryStream(fileBytes);

                // Создаем объект класса StreamReader на основе MemoryStream
                StreamReader reader = new StreamReader(stream);

                // Устанавливаем обработчик события PrintPage
                pd.PrintPage += (sender1, e1) =>
                {
                    // Считываем одну строку из файла
                    string line = reader.ReadLine();

                    // Пока не достигнут конец файла
                    if (line != null)
                    {
                        // Рисуем строку на странице
                        e1.Graphics.DrawString(line, new Font("Arial", 12), Brushes.Black, 0, e1.PageBounds.Top + 100);
                        e1.HasMorePages = true;
                    }
                    else
                    {
                        e1.HasMorePages = false;
                    }
                };

                // Запускаем процесс печати
                pd.Print();
            }
        }

        private void предварительныйПросмоторToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //printPreviewDialog1.Document = printDocument1;
        }

        private void настройкаПринтераToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void вырезатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectedText != "")
            {
                richTextBox.Cut();
            }
        }

        private void копироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextBox.Text);
        }

        private void вставитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            {
                richTextBox.Paste();
            }
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();
        }

        private void цветToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectionLength > 0)
            {
                ColorDialog colorDialog = new ColorDialog();
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    richTextBox.SelectionColor = colorDialog.Color;
                }
            }
        }

        private void шрифтToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            DialogResult result = fontDialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                richTextBox.SelectionFont = fontDialog.Font;
            }
        }

        private void оПрограммеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AboutBox1 form = new AboutBox1();
            form.Show(this);
        }
    }
}
