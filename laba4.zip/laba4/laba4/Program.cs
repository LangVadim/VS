﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using M = System.Math;

namespace laba4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[,]
            {
                {0, 1, 2, 3, 4, 5},
                {6, 0, 7, 8, 9, 10},
                {11, 12, 0, 13, 14, 15},
                {16, 17, 18, 0, 19, 20},
                {21, 22, 23, 24, 0, 25},
                {26, 27, 28, 29, 30, 0},
            };

            for(int i = 0; i < 6; i++) 
            {
                for(int j = 0; j < 6; j++) 
                {
                    if (i == j) continue;

                    int sum = 0;
                    for(int n = 0; n < 6; n++)
                    {
                        sum += Math.Max(matrix[i, n], matrix[n, j]);
                    }
                    matrix[i, j] = sum;
                }
            }

            for(int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    if (i == j) matrix[i, j] = 1000;

                    matrix[i, j] *= matrix[i, j];
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }
        }

        public static int Max(int x, int y)
        {
            return x > y ? x : y;
        }
    }
}
