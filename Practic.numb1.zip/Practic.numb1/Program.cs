﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practic.numb1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n1_1, n1_2, n1_1And2, n1_4, n1_5, n1_6, n_1;
            double n2_1, n2_2, n_2;
            double n3_1, n3_2, n_3;
            double res;

            n1_1 = (34.06 - 33.81) * 4;
            n1_2 = 6.84 / (28.57 - 25.15);
            n1_1And2 = n1_1 / n1_2;
            n1_4 = 3 + (4.2 / 0.1);
            n1_5 = (1 / 0.3 - 2.7) / 4.12;
            n1_6 = Math.Sqrt(n1_4 / n1_5);
            n_1 = 26 / (n1_1And2 - n1_6);

            //n2_1 = 2 / 3;
            //n2_2 = 4 / 21; 
            n_2 = 3.5;

            n3_1 = 1 + Math.Pow(5, 1.0 / 3.0);
            n3_2 = n3_1 / 3.5;
            n_3 = Math.Pow(n3_2, 0.2);

            res = n_1 + n_2 + n_3;

            Console.WriteLine(res);
        }
    }
}
